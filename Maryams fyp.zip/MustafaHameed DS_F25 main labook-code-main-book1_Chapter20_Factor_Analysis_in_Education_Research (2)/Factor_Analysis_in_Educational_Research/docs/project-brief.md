﻿# Project Brief

## Student attribution

| Role | Name | Roll No | Project title |
|---|---|---|---|
| **Primary** | MARYAM AHMAD | `F22BINFT1M01117` | Enhancing Data Quality in Student Records Using R-Based Data Cleaning Pipelines |
| Secondary | - | - | - |

Section: Fall 2025 BSIT (7th semester) FYP cohort.


## Domain

Factor analysis for educational survey design and learner-experience measurement.

## Summary

The backend evaluates whether the Chapter 20 survey is suitable for latent-variable analysis, extracts a three-factor structure, fits a confirmatory model on a holdout split, and powers a frontend where users enter item responses to estimate the dominant latent learning factor.

