$projectRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
$backendScript = Join-Path $projectRoot "backend\run_factor_pipeline.py"
$preferredPython = "C:\ProgramData\anaconda3\python.exe"

Set-Location $projectRoot
if (Test-Path $preferredPython) {
    $python = $preferredPython
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $python = (Get-Command python).Source
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
    $python = (Get-Command py).Source
} else {
    throw "Python was not found on PATH. Install Python before running the pipeline."
}

$requirements = Join-Path $projectRoot "requirements.txt"
if (Test-Path $requirements) {
    & $python -m pip install --quiet -r $requirements
}

& $python $backendScript
