# Output Artifacts

The backend writes `dashboard.json` plus CSV traces for item diagnostics, scree statistics, loadings, communalities, and confirmatory fit summaries.
