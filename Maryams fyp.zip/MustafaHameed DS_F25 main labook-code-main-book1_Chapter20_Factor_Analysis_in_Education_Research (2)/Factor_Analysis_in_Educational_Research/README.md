﻿# Factor Analysis in Educational research

## Student attribution

| Role | Name | Roll No | Project title |
|---|---|---|---|
| **Primary** | MARYAM AHMAD | `F22BINFT1M01117` | Enhancing Data Quality in Student Records Using R-Based Data Cleaning Pipelines |
| Secondary | - | - | - |

Section: Fall 2025 BSIT (7th semester) FYP cohort.


This Python-first FYP translates Chapter 20 into a factor-analysis workflow using the chapter-local `educational_survey_data.csv` file, exploratory factor extraction, confirmatory holdout checking, and a manual survey-response demo.

## Run Instructions

### Primary launcher

From PowerShell:

```powershell
.\run\run_project.bat
```

This is the recommended one-step launcher. It installs required Python packages, refreshes backend artifacts, starts the project-local web server, and opens the dashboard automatically.

If you prefer calling the PowerShell script directly, use:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\run\run_project.ps1
```

Optional switches: `-SkipPipeline` uses existing artifacts and `-NoBrowser` starts the local server without opening a browser window.

If students prefer a double-click launcher in File Explorer, use `run\run_project.bat`.

### Other launchers

- `run\run_backend.ps1` or `run\run_backend.bat`: regenerate backend artifacts only.
- `run\run_frontend.ps1` or `run\run_frontend.bat`: serve the frontend only.
- `run\run_notebook.ps1` or `run\run_notebook.bat`: open the notebook-equivalent workflow.

