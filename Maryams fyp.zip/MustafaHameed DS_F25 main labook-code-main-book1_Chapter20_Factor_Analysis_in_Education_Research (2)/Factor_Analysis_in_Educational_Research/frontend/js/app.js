const DASHBOARD_URL = "../outputs/backend/dashboard.json";
const API_PORT = (typeof window !== "undefined" && window.FYP_API_PORT) || 9520;
const API_BASE = `http://127.0.0.1:${API_PORT}`;

let dashboardData = null;
let manualRequestSeq = 0;
let latestManualResult = null;
const MANUAL_HISTORY_KEY = "latent-learning-manual-history";

document.addEventListener("DOMContentLoaded", () => initializeDashboard());

async function initializeDashboard() {
    setStatus("Loading factor-analysis project artifacts...");
    setActiveNavigation();
    setupDatasetUpload();
    try {
        const response = await fetch(DASHBOARD_URL, { cache: "no-store" });
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        dashboardData = await response.json();
        renderMeta();
        renderOverview();
        renderInsightCards();
        renderScree();
        renderLoadings();
        renderCommunalities();
        renderFitChart();
        buildManualForm();
        renderItemTable();
        renderProfileTable();
        setStatus("Live backend artifact loaded successfully.");
    } catch (error) {
        console.error(error);
        setStatus("Backend output is missing. Run ./run/run_backend.ps1 and refresh this page.");
    }
}

function hasElement(id) {
    return Boolean(document.getElementById(id));
}

function text(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.textContent = value;
    }
}

function renderMeta() {
    const generatedAt = dashboardData.project?.generated_at || "unknown";
    text("generatedAt", `Generated: ${generatedAt}`);
    text("projectTitle", dashboardData.project?.title || "Factor Analysis in Educational research");
}

function renderOverview() {
    const overview = dashboardData.overview || {};
    text("respondents", overview.respondents ?? "--");
    text("suggestedFactors", overview.suggested_factors ?? "--");
    text("kmoOverall", Number(overview.kmo_overall).toFixed(3));
    text("holdoutCfi", overview.holdout_cfi === null ? "n/a" : Number(overview.holdout_cfi).toFixed(3));
    text("varianceCaptured", `${(Number(overview.variance_first_three || 0) * 100).toFixed(1)}%`);
}

function renderInsightCards() {
    const factorability = dashboardData.factorability || {};
    text("bartlettP", formatPValue(factorability.bartlett_p_value));
    text("factorCount", `${dashboardData.overview?.suggested_factors ?? "--"} factors`);
    text("itemCount", `${(dashboardData.item_metrics || []).length} items`);
    text("apiPort", `:${API_PORT}`);
}

function renderScree() {
    if (!hasElement("screeChart")) return;
    const rows = dashboardData.scree || [];
    Plotly.newPlot("screeChart", [
        {
            type: "scatter",
            mode: "lines+markers",
            name: "Eigenvalue",
            x: rows.map((row) => row.component),
            y: rows.map((row) => row.eigenvalue),
            line: { color: "#22d3ee", width: 4 },
            marker: { size: 10, color: "#0f172a", line: { color: "#67e8f9", width: 2 } },
        },
        {
            type: "bar",
            name: "Cumulative variance",
            x: rows.map((row) => row.component),
            y: rows.map((row) => row.cumulative_ratio),
            yaxis: "y2",
            opacity: 0.38,
            marker: { color: "#64748b" },
        },
    ], chartLayout({
        xaxis: { title: "Component" },
        yaxis: { title: "Eigenvalue", gridcolor: "#e5e7eb" },
        yaxis2: { title: "Cumulative variance", overlaying: "y", side: "right", range: [0, 1.05] },
        legend: { orientation: "h", y: -0.2 },
    }), quietPlotConfig());
}

function renderLoadings() {
    if (!hasElement("loadingsHeatmap")) return;
    const payload = dashboardData.loadings;
    Plotly.newPlot("loadingsHeatmap", [{
        type: "heatmap",
        x: payload.columns,
        y: payload.index,
        z: payload.data,
        colorscale: [[0, "#0f172a"], [0.35, "#334155"], [0.5, "#e2e8f0"], [0.72, "#0891b2"], [1, "#22d3ee"]],
        reversescale: false,
        zmid: 0,
    }], chartLayout({
        margin: { t: 20, r: 20, b: 80, l: 140 },
    }), quietPlotConfig());
}

function renderCommunalities() {
    if (!hasElement("communalityChart")) return;
    const rows = dashboardData.communalities || [];
    Plotly.newPlot("communalityChart", [
        {
            type: "bar",
            x: rows.map((row) => row.item),
            y: rows.map((row) => row.communality),
            marker: { color: "#0891b2" },
        },
    ], chartLayout({
        margin: { t: 20, r: 20, b: 110, l: 50 },
        yaxis: { title: "Communality", gridcolor: "#e5e7eb" },
    }), quietPlotConfig());
}

function renderFitChart() {
    if (!hasElement("fitChart")) return;
    const metrics = ["cfi", "tli", "rmsea"];
    const labels = ["CFI", "TLI", "RMSEA"];
    Plotly.newPlot("fitChart", [
        {
            type: "bar",
            name: "Model-building",
            x: labels,
            y: metrics.map((metric) => dashboardData.cfa_fit[metric]),
            marker: { color: "#64748b" },
        },
        {
            type: "bar",
            name: "Holdout",
            x: labels,
            y: metrics.map((metric) => dashboardData.holdout_fit[metric]),
            marker: { color: "#0891b2" },
        },
    ], chartLayout({
        yaxis: { title: "Fit value", gridcolor: "#e5e7eb" },
        barmode: "group",
    }), quietPlotConfig());
}

function setupDatasetUpload() {
    const input = document.getElementById("datasetUpload");
    const clearButton = document.getElementById("clearDatasetButton");
    const columnSelect = document.getElementById("datasetColumnSelect");
    if (!input) return;
    input.addEventListener("change", () => {
        const file = input.files?.[0];
        if (!file) return;
        readUploadedDataset(file);
    });
    if (clearButton) clearButton.addEventListener("click", clearUploadedDataset);
    if (columnSelect) columnSelect.addEventListener("change", () => {
        const selectedColumn = columnSelect.value;
        if (window.uploadedDatasetProfile && selectedColumn) {
            renderUploadedDistribution(window.uploadedDatasetProfile, selectedColumn);
        }
    });
}

function readUploadedDataset(file) {
    if (/\.(xlsx|xls)$/i.test(file.name)) {
        setDatasetMessage("Excel files are not supported in this browser-only tool. Please save the sheet as CSV and upload that file.");
        return;
    }
    text("uploadedFileName", file.name);
    setDatasetMessage(`Reading ${file.name}...`);
    const reader = new FileReader();
    reader.addEventListener("load", () => {
        try {
            const parsed = parseCsv(String(reader.result || ""));
            const profile = profileDataset(parsed.headers, parsed.rows);
            window.uploadedDatasetProfile = profile;
            renderUploadedDataset(profile, file.name);
        } catch (error) {
            console.error(error);
            setDatasetMessage(`Could not analyze this file. ${error.message}`);
            clearUploadedCharts();
        }
    });
    reader.addEventListener("error", () => {
        setDatasetMessage("Could not read the selected file.");
    });
    reader.readAsText(file);
}

function parseCsv(source) {
    const delimiter = detectDelimiter(source);
    const rows = [];
    let current = "";
    let row = [];
    let inQuotes = false;
    for (let index = 0; index < source.length; index += 1) {
        const char = source[index];
        const next = source[index + 1];
        if (char === '"' && inQuotes && next === '"') {
            current += '"';
            index += 1;
        } else if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === delimiter && !inQuotes) {
            row.push(current.trim());
            current = "";
        } else if ((char === "\n" || char === "\r") && !inQuotes) {
            if (char === "\r" && next === "\n") index += 1;
            row.push(current.trim());
            if (row.some((cell) => cell !== "")) rows.push(row);
            row = [];
            current = "";
        } else {
            current += char;
        }
    }
    row.push(current.trim());
    if (row.some((cell) => cell !== "")) rows.push(row);
    if (rows.length < 2) {
        throw new Error("A CSV needs a header row and at least one data row.");
    }
    const headers = rows[0].map((header, index) => header || `Column ${index + 1}`);
    const dataRows = rows.slice(1).map((cells) => {
        const record = {};
        headers.forEach((header, index) => {
            record[header] = cells[index] ?? "";
        });
        return record;
    });
    return { headers, rows: dataRows, delimiter };
}

function detectDelimiter(source) {
    const sampleLine = source.split(/\r?\n/).find((line) => line.trim()) || "";
    const delimiters = [",", ";", "\t", "|"];
    let bestDelimiter = ",";
    let bestCount = 0;
    delimiters.forEach((delimiter) => {
        const count = countDelimiterOutsideQuotes(sampleLine, delimiter);
        if (count > bestCount) {
            bestCount = count;
            bestDelimiter = delimiter;
        }
    });
    return bestDelimiter;
}

function countDelimiterOutsideQuotes(line, delimiter) {
    let count = 0;
    let inQuotes = false;
    for (let index = 0; index < line.length; index += 1) {
        const char = line[index];
        const next = line[index + 1];
        if (char === '"' && inQuotes && next === '"') {
            index += 1;
        } else if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === delimiter && !inQuotes) {
            count += 1;
        }
    }
    return count;
}

function profileDataset(headers, rows) {
    const totalCells = headers.length * rows.length;
    const missingCells = rows.reduce((sum, row) => {
        return sum + headers.filter((header) => isMissing(row[header])).length;
    }, 0);
    const numericSummaries = headers.map((header) => {
        const values = rows.map((row) => parseNumericCell(row[header])).filter(Number.isFinite);
        const missing = rows.length - values.length;
        if (!values.length) return null;
        const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
        const variance = values.reduce((sum, value) => sum + Math.pow(value - mean, 2), 0) / Math.max(values.length - 1, 1);
        return {
            column: header,
            values,
            count: values.length,
            missing,
            mean,
            std: Math.sqrt(variance),
            min: Math.min(...values),
            max: Math.max(...values),
        };
    }).filter(Boolean);
    return { headers, rows, totalCells, missingCells, numericSummaries };
}

function renderUploadedDataset(profile, filename) {
    text("uploadedRows", profile.rows.length);
    text("uploadedColumns", profile.headers.length);
    text("uploadedNumeric", profile.numericSummaries.length);
    text("uploadedMissing", profile.missingCells);
    setDatasetMessage(`Analyzed ${filename}: ${profile.rows.length} rows, ${profile.headers.length} columns, ${profile.numericSummaries.length} numeric columns.`);
    renderUploadedSummaryTable(profile.numericSummaries);
    renderUploadedPreview(profile);
    renderDatasetColumnOptions(profile.numericSummaries);
    renderUploadedCorrelation(profile);
    if (profile.numericSummaries[0]) {
        renderUploadedDistribution(profile, profile.numericSummaries[0].column);
    } else {
        clearUploadedCharts();
        setDatasetMessage("Dataset uploaded, but no numeric columns were found for analytics.");
    }
}

function renderUploadedSummaryTable(summaries) {
    const body = document.getElementById("datasetSummaryBody");
    if (!body) return;
    body.innerHTML = "";
    if (!summaries.length) {
        body.innerHTML = `<tr><td colspan="7">No numeric columns found.</td></tr>`;
        return;
    }
    summaries.forEach((summary) => {
        const row = document.createElement("tr");
        [
            summary.column,
            summary.count,
            summary.mean.toFixed(3),
            summary.std.toFixed(3),
            summary.min.toFixed(3),
            summary.max.toFixed(3),
            summary.missing,
        ].forEach((value) => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });
        body.appendChild(row);
    });
}

function renderUploadedPreview(profile) {
    const head = document.getElementById("datasetPreviewHead");
    const body = document.getElementById("datasetPreviewBody");
    if (!head || !body) return;
    const headers = profile.headers.slice(0, 6);
    head.innerHTML = "";
    body.innerHTML = "";
    const headerRow = document.createElement("tr");
    headers.forEach((header) => {
        const cell = document.createElement("th");
        cell.textContent = header;
        headerRow.appendChild(cell);
    });
    head.appendChild(headerRow);
    profile.rows.slice(0, 5).forEach((record) => {
        const row = document.createElement("tr");
        headers.forEach((header) => {
            const cell = document.createElement("td");
            const value = record[header];
            cell.textContent = String(value ?? "").slice(0, 80);
            row.appendChild(cell);
        });
        body.appendChild(row);
    });
    if (!profile.rows.length) {
        body.innerHTML = `<tr><td>No rows found.</td></tr>`;
    }
}

function renderDatasetColumnOptions(summaries) {
    const select = document.getElementById("datasetColumnSelect");
    if (!select) return;
    select.innerHTML = `<option value="">Select numeric column</option>`;
    summaries.forEach((summary, index) => {
        const option = document.createElement("option");
        option.value = summary.column;
        option.textContent = summary.column;
        option.selected = index === 0;
        select.appendChild(option);
    });
}

function renderUploadedCorrelation(profile) {
    if (!hasElement("uploadedCorrelationChart")) return;
    const summaries = profile.numericSummaries.slice(0, 12);
    if (summaries.length < 2) {
        Plotly.purge("uploadedCorrelationChart");
        return;
    }
    const labels = summaries.map((summary) => summary.column);
    const matrix = labels.map((left) => labels.map((right) => correlationForColumns(profile.rows, left, right)));
    Plotly.newPlot("uploadedCorrelationChart", [{
        type: "heatmap",
        x: labels,
        y: labels,
        z: matrix,
        zmin: -1,
        zmax: 1,
        colorscale: [[0, "#0f172a"], [0.35, "#334155"], [0.5, "#e2e8f0"], [0.72, "#0891b2"], [1, "#22d3ee"]],
        reversescale: false,
    }], chartLayout({
        margin: { t: 20, r: 20, b: 120, l: 130 },
    }), quietPlotConfig());
}

function renderUploadedDistribution(profile, column) {
    if (!hasElement("uploadedDistributionChart")) return;
    const summary = profile.numericSummaries.find((entry) => entry.column === column);
    if (!summary) {
        Plotly.purge("uploadedDistributionChart");
        return;
    }
    Plotly.newPlot("uploadedDistributionChart", [{
        type: "histogram",
        x: summary.values,
        marker: { color: "#0891b2", line: { color: "#e2e8f0", width: 1 } },
    }], chartLayout({
        xaxis: { title: column, gridcolor: "#edf2f7" },
        yaxis: { title: "Frequency", gridcolor: "#edf2f7" },
    }), quietPlotConfig());
}

function correlationForColumns(rows, left, right) {
    const pairs = rows.map((row) => [parseNumericCell(row[left]), parseNumericCell(row[right])])
        .filter(([leftValue, rightValue]) => Number.isFinite(leftValue) && Number.isFinite(rightValue));
    if (pairs.length < 2) return 0;
    const leftMean = pairs.reduce((sum, pair) => sum + pair[0], 0) / pairs.length;
    const rightMean = pairs.reduce((sum, pair) => sum + pair[1], 0) / pairs.length;
    let numerator = 0;
    let leftDenominator = 0;
    let rightDenominator = 0;
    pairs.forEach(([leftValue, rightValue]) => {
        const leftDelta = leftValue - leftMean;
        const rightDelta = rightValue - rightMean;
        numerator += leftDelta * rightDelta;
        leftDenominator += leftDelta * leftDelta;
        rightDenominator += rightDelta * rightDelta;
    });
    const denominator = Math.sqrt(leftDenominator * rightDenominator);
    return denominator ? numerator / denominator : 0;
}

function clearUploadedDataset() {
    window.uploadedDatasetProfile = null;
    const input = document.getElementById("datasetUpload");
    if (input) input.value = "";
    text("uploadedRows", "--");
    text("uploadedColumns", "--");
    text("uploadedNumeric", "--");
    text("uploadedMissing", "--");
    text("uploadedFileName", "CSV, TSV, or text-delimited data works best.");
    renderUploadedSummaryTable([]);
    clearUploadedPreview();
    renderDatasetColumnOptions([]);
    clearUploadedCharts();
    setDatasetMessage("Upload a CSV file to generate quick analytics.");
}

function clearUploadedPreview() {
    const head = document.getElementById("datasetPreviewHead");
    const body = document.getElementById("datasetPreviewBody");
    if (head) head.innerHTML = `<tr><th>Preview</th></tr>`;
    if (body) body.innerHTML = `<tr><td>Upload a dataset to preview rows.</td></tr>`;
}

function clearUploadedCharts() {
    if (hasElement("uploadedCorrelationChart")) Plotly.purge("uploadedCorrelationChart");
    if (hasElement("uploadedDistributionChart")) Plotly.purge("uploadedDistributionChart");
}

function setDatasetMessage(message) {
    text("datasetMessage", message);
}

function isMissing(value) {
    return value === null || value === undefined || String(value).trim() === "";
}

function parseNumericCell(value) {
    if (isMissing(value)) return NaN;
    const numeric = Number(String(value).replaceAll(",", ""));
    return Number.isFinite(numeric) ? numeric : NaN;
}

function buildManualForm() {
    const form = document.getElementById("manualForm");
    if (!form) return;
    form.innerHTML = "";
    for (const field of dashboardData.manual_demo.field_schema || []) {
        const wrapper = document.createElement("div");
        wrapper.className = "input-field";
        wrapper.innerHTML = `<label for="field-${field.name}">${field.name}</label><small>${field.group}</small>`;
        const input = document.createElement("input");
        input.type = "range";
        input.min = "1";
        input.max = "5";
        input.step = "0.1";
        input.id = `field-${field.name}`;
        input.value = field.default;
        const value = document.createElement("span");
        value.className = "range-value";
        value.textContent = Number(field.default).toFixed(1);
        input.addEventListener("input", () => {
            value.textContent = Number(input.value).toFixed(1);
        });
        const row = document.createElement("div");
        row.className = "range-row";
        row.appendChild(input);
        row.appendChild(value);
        wrapper.appendChild(row);
        form.appendChild(wrapper);
    }
    const actions = document.createElement("div");
    actions.className = "form-actions";
    const submitButton = document.createElement("button");
    submitButton.type = "submit";
    submitButton.textContent = "Estimate Factors";
    const resetButton = document.createElement("button");
    resetButton.type = "button";
    resetButton.className = "secondary";
    resetButton.textContent = "Reset Means";
    resetButton.addEventListener("click", () => {
        for (const field of dashboardData.manual_demo.field_schema || []) {
            const input = document.getElementById(`field-${field.name}`);
            input.value = field.default;
            input.dispatchEvent(new Event("input"));
        }
        runManualAnalysis({ saveHistory: false });
    });
    actions.appendChild(submitButton);
    actions.appendChild(resetButton);
    form.appendChild(actions);
    form.addEventListener("submit", (event) => {
        event.preventDefault();
        runManualAnalysis({ saveHistory: true });
    });
    setupManualActions();
    renderHistoryTable();
    runManualAnalysis({ saveHistory: false });
}

async function runManualAnalysis(options = {}) {
    const summary = document.getElementById("manualSummary");
    if (!summary) return;
    const fields = dashboardData.manual_demo.field_schema || [];
    const values = {};
    for (const field of fields) {
        values[field.name] = Number(document.getElementById(`field-${field.name}`).value || 0);
    }
    const requestId = ++manualRequestSeq;
    summary.innerHTML = "<em>Contacting backend API...</em>";
    let payload;
    try {
        const response = await fetch(`${API_BASE}/predict`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ values })
        });
        payload = await response.json();
        if (!response.ok) {
            summary.innerHTML = `<strong>Backend error (HTTP ${response.status}).</strong><br><small>${payload.detail || payload.error || ""}</small>`;
            return;
        }
    } catch (error) {
        if (requestId !== manualRequestSeq) return;
        summary.innerHTML = `<strong>Backend unreachable.</strong> Start <code>run/run_backend.ps1</code> (port ${API_PORT}).<br><small>${error.message}</small>`;
        return;
    }
    if (requestId !== manualRequestSeq) return;

    const ranked = payload.ranked || [];
    const dominant = payload.prediction || {};
    latestManualResult = {
        timestamp: new Date().toLocaleString(),
        values,
        prediction: dominant,
        ranked,
        factor_scores: payload.factor_scores || {},
    };
    summary.innerHTML = `<strong>Dominant estimated factor: ${dominant.dominant_factor || "--"}</strong><span class="score-line">Score: ${Number(dominant.score ?? 0).toFixed(3)}</span><br>${factorInterpretation(dominant.dominant_factor)}<br><small>Served by FastAPI on :${API_PORT}</small>`;
    renderManualResultTable(ranked);
    renderProfileReport(latestManualResult);
    if (options.saveHistory) {
        saveHistory(latestManualResult);
        renderHistoryTable();
    }
    if (!hasElement("manualChart")) return;
    Plotly.newPlot("manualChart", [{
        type: "bar",
        x: ranked.map((entry) => entry.factor),
        y: ranked.map((entry) => entry.score),
        marker: { color: ["#22d3ee", "#0891b2", "#64748b"] },
    }], chartLayout({
        margin: { t: 20, r: 20, b: 80, l: 50 },
        yaxis: { title: "Weighted factor score", gridcolor: "#e5e7eb" },
    }), quietPlotConfig());
}

function renderManualResultTable(ranked) {
    const body = document.getElementById("manualResultTable");
    if (!body) return;
    body.innerHTML = "";
    ranked.forEach((entry, index) => {
        const score = Number(entry.score ?? 0);
        const row = document.createElement("tr");
        row.innerHTML = `<td>${index + 1}</td><td>${entry.factor}</td><td>${score.toFixed(4)}</td><td>${score >= 0 ? "Above average tendency" : "Below average tendency"}</td>`;
        body.appendChild(row);
    });
}

function setupManualActions() {
    const jsonButton = document.getElementById("exportJsonButton");
    const csvButton = document.getElementById("exportCsvButton");
    const printButton = document.getElementById("printReportButton");
    const clearButton = document.getElementById("clearHistoryButton");
    if (jsonButton) jsonButton.addEventListener("click", exportLatestJson);
    if (csvButton) csvButton.addEventListener("click", exportLatestCsv);
    if (printButton) printButton.addEventListener("click", printLatestReport);
    if (clearButton) clearButton.addEventListener("click", () => {
        window.localStorage.removeItem(MANUAL_HISTORY_KEY);
        renderHistoryTable();
    });
}

function renderProfileReport(result) {
    const report = document.getElementById("profileReport");
    if (!report || !result) return;
    const factor = result.prediction?.dominant_factor || "--";
    const score = Number(result.prediction?.score ?? 0);
    report.innerHTML = `
        <div class="report-banner">
            <span class="metric-label">Dominant Factor</span>
            <strong>${factor}</strong>
            <p>Score: ${score.toFixed(3)} | Generated: ${result.timestamp}</p>
        </div>
        <div class="report-grid">
            <div class="signal-tile"><strong>${strengthLabel(score)}</strong><p>Profile strength</p></div>
            <div class="signal-tile"><strong>${(Number(dashboardData.overview.variance_first_three || 0) * 100).toFixed(1)}%</strong><p>Variance captured</p></div>
            <div class="signal-tile"><strong>${formatPValue(dashboardData.factorability.bartlett_p_value)}</strong><p>Bartlett p-value</p></div>
        </div>
        <div class="report-note"><strong>Interpretation:</strong> ${factorInterpretation(factor)}</div>
        <div class="report-note"><strong>Recommendation:</strong> ${factorRecommendation(factor, score)}</div>
    `;
}

function getHistory() {
    try {
        return JSON.parse(window.localStorage.getItem(MANUAL_HISTORY_KEY) || "[]");
    } catch {
        return [];
    }
}

function saveHistory(result) {
    const history = [result, ...getHistory()].slice(0, 10);
    window.localStorage.setItem(MANUAL_HISTORY_KEY, JSON.stringify(history));
}

function renderHistoryTable() {
    const body = document.getElementById("historyTableBody");
    if (!body) return;
    const history = getHistory();
    body.innerHTML = "";
    if (!history.length) {
        body.innerHTML = `<tr><td colspan="3">No saved predictions yet.</td></tr>`;
        return;
    }
    history.forEach((entry) => {
        const row = document.createElement("tr");
        row.innerHTML = `<td>${entry.timestamp}</td><td>${entry.prediction?.dominant_factor || "--"}</td><td>${Number(entry.prediction?.score ?? 0).toFixed(3)}</td>`;
        body.appendChild(row);
    });
}

function exportLatestJson() {
    if (!latestManualResult) return;
    downloadFile("student-factor-profile.json", JSON.stringify(latestManualResult, null, 2), "application/json");
}

function exportLatestCsv() {
    if (!latestManualResult) return;
    const rows = [
        ["section", "name", "value"],
        ["prediction", "dominant_factor", latestManualResult.prediction?.dominant_factor || ""],
        ["prediction", "score", latestManualResult.prediction?.score ?? ""],
        ...Object.entries(latestManualResult.values).map(([name, value]) => ["input", name, value]),
        ...latestManualResult.ranked.map((entry) => ["factor_score", entry.factor, entry.score]),
    ];
    const csv = rows.map((row) => row.map(csvCell).join(",")).join("\n");
    downloadFile("student-factor-profile.csv", csv, "text/csv");
}

function printLatestReport() {
    if (!latestManualResult) return;
    window.print();
}

function downloadFile(filename, content, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}

function csvCell(value) {
    const textValue = String(value ?? "");
    return `"${textValue.replaceAll('"', '""')}"`;
}

function factorInterpretation(factor) {
    const map = {
        "Academic Engagement": "The learner profile is strongest in attendance, assignment completion, and effort quality.",
        "Social Presence": "The learner profile is strongest in peer interaction, forum participation, and helping classmates.",
        "Course Satisfaction": "The learner profile is strongest in course satisfaction, recommendation intent, and instructor clarity.",
    };
    return map[factor] || "The model needs a valid dominant factor before a profile can be interpreted.";
}

function factorRecommendation(factor, score) {
    const tone = Number(score) >= 0 ? "Maintain this strength while improving weaker dimensions." : "This area may need support and targeted improvement.";
    const map = {
        "Academic Engagement": "Encourage consistent lecture attendance, timely assignment completion, and reflective study habits.",
        "Social Presence": "Encourage discussion participation, peer collaboration, and structured classmate support.",
        "Course Satisfaction": "Review course clarity, feedback quality, and learner confidence in recommending the course.",
    };
    return `${map[factor] || "Review the ranked factor scores for the best next action."} ${tone}`;
}

function strengthLabel(score) {
    const value = Math.abs(Number(score) || 0);
    if (value >= 5) return "Very strong";
    if (value >= 2.5) return "Strong";
    if (value >= 1) return "Moderate";
    return "Balanced";
}

function renderItemTable() {
    const body = document.getElementById("itemTableBody");
    if (!body) return;
    body.innerHTML = "";
    for (const row of dashboardData.item_metrics || []) {
        const element = document.createElement("tr");
        element.innerHTML = `<td>${row.item}</td><td>${Number(row.kmo).toFixed(3)}</td><td>${Number(row.mean).toFixed(3)}</td><td>${Number(row.std).toFixed(3)}</td>`;
        body.appendChild(element);
    }
}

function renderProfileTable() {
    const body = document.getElementById("profileTableBody");
    if (!body) return;
    body.innerHTML = "";
    for (const row of dashboardData.top_profiles || []) {
        const element = document.createElement("tr");
        element.innerHTML = `<td>${row.respondent_id}</td><td>${row.dominant_factor}</td><td>${Number(row["Academic Engagement"]).toFixed(3)}</td><td>${Number(row["Social Presence"]).toFixed(3)}</td><td>${Number(row["Course Satisfaction"]).toFixed(3)}</td>`;
        body.appendChild(element);
    }
}

function chartLayout(overrides = {}) {
    return {
        margin: { t: 20, r: 35, b: 65, l: 55 },
        paper_bgcolor: "rgba(0,0,0,0)",
        plot_bgcolor: "rgba(0,0,0,0)",
        font: { family: "Inter, Segoe UI, Arial", color: "#334155", size: 12 },
        hoverlabel: { bgcolor: "#17202a", bordercolor: "#17202a", font: { color: "#ffffff" } },
        xaxis: { automargin: true, gridcolor: "#edf2f7", zerolinecolor: "#d9e1ea" },
        yaxis: { automargin: true, gridcolor: "#edf2f7", zerolinecolor: "#d9e1ea" },
        ...overrides,
    };
}

function formatPValue(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric === 0) {
        return "< 1e-6";
    }
    return numeric.toExponential(2);
}

function quietPlotConfig() {
    return { responsive: true, displayModeBar: false };
}

function setStatus(message) {
    text("statusMessage", message);
}

function setActiveNavigation() {
    const currentPage = window.location.pathname.split("/").pop() || "index.html";
    for (const link of document.querySelectorAll("[data-nav]")) {
        const href = link.getAttribute("href");
        const isActive = href === currentPage || (currentPage === "" && href === "index.html");
        link.classList.toggle("is-active", isActive);
    }
}
