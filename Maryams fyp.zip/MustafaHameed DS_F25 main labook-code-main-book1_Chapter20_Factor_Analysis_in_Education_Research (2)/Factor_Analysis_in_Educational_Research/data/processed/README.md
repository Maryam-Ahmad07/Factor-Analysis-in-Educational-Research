# Processed Data

`respondent_factor_scores.csv` stores each respondent's observed item values together with the generated factor scores from the exploratory model.
