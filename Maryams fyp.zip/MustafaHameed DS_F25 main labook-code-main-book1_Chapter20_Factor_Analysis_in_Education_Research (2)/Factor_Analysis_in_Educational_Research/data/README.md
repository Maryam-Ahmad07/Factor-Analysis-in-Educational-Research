# Data Overview

This package keeps its runtime data local to the FYP folder.

- `raw/educational_survey_data.csv`: copied Chapter 20 survey-response dataset.
- `processed/respondent_factor_scores.csv`: generated respondent-level factor scores.
