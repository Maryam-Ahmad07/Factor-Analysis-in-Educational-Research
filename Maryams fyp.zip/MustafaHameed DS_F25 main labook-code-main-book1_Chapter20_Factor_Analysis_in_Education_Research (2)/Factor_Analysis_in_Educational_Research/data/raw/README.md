# Raw Data

`educational_survey_data.csv` is copied from the Chapter 20 folder so the packaged backend runs without touching the original tutorial files.
