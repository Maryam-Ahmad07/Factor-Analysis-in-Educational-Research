from __future__ import annotations

import json
import os
from itertools import permutations
from pathlib import Path
from typing import Callable

os.environ.setdefault("OMP_NUM_THREADS", "1")

import numpy as np
import pandas as pd
from factor_analyzer import FactorAnalyzer, calculate_bartlett_sphericity, calculate_kmo
from semopy import Model, calc_stats


RANDOM_SEED = 19
ITEM_GROUPS = {
    "Academic Engagement": ["Attend_Lectures", "Complete_Assignments", "Effort_Quality"],
    "Social Presence": ["Peer_Interaction", "Forum_Participation", "Help_Classmates"],
    "Course Satisfaction": ["Satisfied_Course", "Would_Recommend", "Instructor_Clarity"],
}
FACTOR_ORDER = list(ITEM_GROUPS.keys())
ITEM_ORDER = [item for items in ITEM_GROUPS.values() for item in items]


def write_artifact(path: Path, writer: Callable[[Path], None]) -> None:
    temp_path = path.with_name(f"{path.stem}.tmp{path.suffix}")
    try:
        writer(temp_path)
        temp_path.replace(path)
    except PermissionError as exc:
        if temp_path.exists():
            try:
                temp_path.unlink(missing_ok=True)
            except PermissionError:
                pass
        raise PermissionError(
            f"Could not update {path}. Close any open copy of this output file and rerun the pipeline."
        ) from exc


def project_paths() -> dict[str, Path]:
    root = Path(__file__).resolve().parent.parent
    processed_dir = root / "data" / "processed"
    output_dir = root / "outputs" / "backend"
    processed_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    return {
        "root": root,
        "processed_dir": processed_dir,
        "output_dir": output_dir,
        "data_path": root / "data" / "raw" / "educational_survey_data.csv",
    }


def load_data(data_path: Path) -> pd.DataFrame:
    data_frame = pd.read_csv(data_path).dropna().copy()
    return data_frame.loc[:, ITEM_ORDER]


def split_holdout(data_frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(RANDOM_SEED)
    indices = rng.permutation(len(data_frame))
    split_point = len(data_frame) // 2
    model_building = data_frame.iloc[indices[:split_point]].reset_index(drop=True)
    holdout = data_frame.iloc[indices[split_point:]].reset_index(drop=True)
    return model_building, holdout


def factorability_metrics(data_frame: pd.DataFrame) -> tuple[dict[str, float], pd.DataFrame]:
    chi_square, p_value = calculate_bartlett_sphericity(data_frame)
    kmo_by_item, kmo_overall = calculate_kmo(data_frame)
    item_metrics = pd.DataFrame(
        {
            "item": ITEM_ORDER,
            "kmo": np.round(kmo_by_item, 4),
            "mean": np.round(data_frame.mean().reindex(ITEM_ORDER), 4),
            "std": np.round(data_frame.std(ddof=1).reindex(ITEM_ORDER), 4),
        }
    )
    return {
        "bartlett_chi_square": round(float(chi_square), 4),
        "bartlett_p_value": round(float(p_value), 8),
        "kmo_overall": round(float(kmo_overall), 4),
        "determinant": round(float(np.linalg.det(data_frame.corr().values)), 8),
    }, item_metrics


def scree_table(data_frame: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    tester = FactorAnalyzer(rotation=None, n_factors=len(ITEM_ORDER), method="ml")
    tester.fit(data_frame)
    eigenvalues, _ = tester.get_eigenvalues()
    rows: list[dict[str, float]] = []
    cumulative = 0.0
    for index, eigenvalue in enumerate(eigenvalues, start=1):
        variance_ratio = float(eigenvalue) / len(ITEM_ORDER)
        cumulative += variance_ratio
        rows.append(
            {
                "component": index,
                "eigenvalue": round(float(eigenvalue), 4),
                "variance_ratio": round(variance_ratio, 4),
                "cumulative_ratio": round(cumulative, 4),
            }
        )
    suggested = max(1, int((np.array(eigenvalues) > 1.0).sum()))
    return pd.DataFrame(rows), suggested


def factor_name_mapping(loadings: pd.DataFrame) -> dict[str, str]:
    scores: dict[tuple[str, ...], float] = {}
    columns = list(loadings.columns)
    for candidate in permutations(columns, len(FACTOR_ORDER)):
        total = 0.0
        for factor_name, column in zip(FACTOR_ORDER, candidate):
            total += float(loadings.loc[ITEM_GROUPS[factor_name], column].abs().mean())
        scores[candidate] = total
    best = max(scores, key=scores.get)
    return {column: factor_name for factor_name, column in zip(FACTOR_ORDER, best)}


def factor_scores_frame(
    analyzer: FactorAnalyzer,
    data_frame: pd.DataFrame,
    mapping: dict[str, str],
    n_factors: int = 3,
) -> pd.DataFrame:
    raw_columns = [f"Factor {index}" for index in range(1, n_factors + 1)]
    factor_scores = pd.DataFrame(analyzer.transform(data_frame), columns=raw_columns)
    return factor_scores.rename(columns=mapping).reindex(columns=FACTOR_ORDER).round(4)


def run_efa(data_frame: pd.DataFrame, n_factors: int = 3) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, FactorAnalyzer, dict[str, str]]:
    analyzer = FactorAnalyzer(n_factors=n_factors, rotation="varimax", method="ml")
    analyzer.fit(data_frame)
    raw_columns = [f"Factor {index}" for index in range(1, n_factors + 1)]
    loadings = pd.DataFrame(analyzer.loadings_, index=ITEM_ORDER, columns=raw_columns)
    mapping = factor_name_mapping(loadings)
    loadings = loadings.rename(columns=mapping).reindex(columns=FACTOR_ORDER)

    factor_scores = factor_scores_frame(analyzer, data_frame, mapping, n_factors=n_factors)

    communalities = pd.DataFrame(
        {
            "item": ITEM_ORDER,
            "communality": np.round(analyzer.get_communalities(), 4),
            "uniqueness": np.round(analyzer.get_uniquenesses(), 4),
        }
    )
    return loadings.round(4), communalities, factor_scores, analyzer, mapping


def cfa_model_spec() -> str:
    return "\n".join(
        [
            "Academic_Engagement =~ Attend_Lectures + Complete_Assignments + Effort_Quality",
            "Social_Presence =~ Peer_Interaction + Forum_Participation + Help_Classmates",
            "Course_Satisfaction =~ Satisfied_Course + Would_Recommend + Instructor_Clarity",
        ]
    )


def stat_value(stats_object: pd.DataFrame, name: str) -> float | None:
    if isinstance(stats_object, pd.DataFrame):
        if name in stats_object.columns:
            value = stats_object[name].iloc[0]
            return None if pd.isna(value) else float(value)
        if name in stats_object.index:
            row = stats_object.loc[name]
            if hasattr(row, "iloc"):
                value = row.iloc[0]
            else:
                value = row
            return None if pd.isna(value) else float(value)
    return None


def fit_cfa(data_frame: pd.DataFrame) -> tuple[dict[str, float | None], pd.DataFrame]:
    model = Model(cfa_model_spec())
    model.fit(data_frame)
    stats_object = calc_stats(model)
    summary = {
        "chi2": stat_value(stats_object, "chi2"),
        "chi2_p_value": stat_value(stats_object, "chi2 p-value"),
        "dof": stat_value(stats_object, "DoF"),
        "cfi": stat_value(stats_object, "CFI"),
        "tli": stat_value(stats_object, "TLI"),
        "gfi": stat_value(stats_object, "GFI"),
        "agfi": stat_value(stats_object, "AGFI"),
        "nfi": stat_value(stats_object, "NFI"),
        "rmsea": stat_value(stats_object, "RMSEA"),
        "aic": stat_value(stats_object, "AIC"),
        "bic": stat_value(stats_object, "BIC"),
    }

    estimates = model.inspect(std_est=True)
    estimate_columns = {column.lower(): column for column in estimates.columns}
    std_column = next((column for column in estimates.columns if "std" in column.lower()), "Estimate")
    loadings = estimates.loc[
        estimates["lval"].isin(ITEM_ORDER) & estimates["rval"].isin(["Academic_Engagement", "Social_Presence", "Course_Satisfaction"]),
        ["lval", "rval", std_column],
    ].copy()
    loadings.columns = ["item", "factor", "standardized_loading"]
    loadings["factor"] = loadings["factor"].map(
        {
            "Academic_Engagement": "Academic Engagement",
            "Social_Presence": "Social Presence",
            "Course_Satisfaction": "Course Satisfaction",
        }
    )
    loadings = loadings.sort_values(["factor", "item"]).reset_index(drop=True)
    loadings["standardized_loading"] = loadings["standardized_loading"].round(4)
    return summary, loadings


def manual_demo_spec(data_frame: pd.DataFrame, loadings: pd.DataFrame) -> dict[str, object]:
    item_stats = data_frame.agg(["mean", "std"]).T.reindex(ITEM_ORDER)
    return {
        "field_schema": [
            {
                "name": item,
                "group": next(group for group, items in ITEM_GROUPS.items() if item in items),
                "default": round(float(item_stats.loc[item, "mean"]), 4),
                "mean": round(float(item_stats.loc[item, "mean"]), 4),
                "std": round(float(item_stats.loc[item, "std"]), 4),
            }
            for item in ITEM_ORDER
        ],
        "factor_weights": {
            factor: {item: round(float(loadings.loc[item, factor]), 4) for item in ITEM_ORDER}
            for factor in FACTOR_ORDER
        },
    }


def build_payload(
    data_frame: pd.DataFrame,
    model_building: pd.DataFrame,
    holdout: pd.DataFrame,
    factorability: dict[str, float],
    item_metrics: pd.DataFrame,
    scree: pd.DataFrame,
    suggested_factors: int,
    loadings: pd.DataFrame,
    communalities: pd.DataFrame,
    factor_scores: pd.DataFrame,
    cfa_fit: dict[str, float | None],
    holdout_fit: dict[str, float | None],
    cfa_loadings: pd.DataFrame,
) -> dict[str, object]:
    labeled_scores = factor_scores.copy()
    labeled_scores.insert(0, "respondent_id", np.arange(1, len(labeled_scores) + 1))
    labeled_scores["dominant_factor"] = labeled_scores[FACTOR_ORDER].abs().idxmax(axis=1)
    top_profiles = (
        labeled_scores.sort_values(["dominant_factor", "Academic Engagement", "Social Presence", "Course Satisfaction"], ascending=[True, False, False, False])
        .groupby("dominant_factor", group_keys=False)
        .head(5)
        .reset_index(drop=True)
    )

    return {
        "project": {
            "title": "Factor Analysis in Educational research",
            "generated_at": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
            "backend": "Python",
            "source_chapter": "Chapter 20",
            "source_qmd": "ch20-fa.qmd",
            "source_notebook": "ch20-factor-analysis.ipynb",
        },
        "overview": {
            "respondents": int(len(data_frame)),
            "items": int(len(ITEM_ORDER)),
            "model_building_n": int(len(model_building)),
            "holdout_n": int(len(holdout)),
            "suggested_factors": int(suggested_factors),
            "analysis_factors": len(FACTOR_ORDER),
            "kmo_overall": factorability["kmo_overall"],
            "bartlett_p_value": factorability["bartlett_p_value"],
            "cfa_cfi": None if cfa_fit["cfi"] is None else round(float(cfa_fit["cfi"]), 4),
            "holdout_cfi": None if holdout_fit["cfi"] is None else round(float(holdout_fit["cfi"]), 4),
            "variance_first_three": round(float(scree.loc[scree["component"] <= 3, "variance_ratio"].sum()), 4),
        },
        "factorability": factorability,
        "item_metrics": json.loads(item_metrics.to_json(orient="records")),
        "scree": json.loads(scree.to_json(orient="records")),
        "loadings": json.loads(loadings.to_json(orient="split")),
        "communalities": json.loads(communalities.to_json(orient="records")),
        "cfa_fit": {key: (None if value is None else round(float(value), 4)) for key, value in cfa_fit.items()},
        "holdout_fit": {key: (None if value is None else round(float(value), 4)) for key, value in holdout_fit.items()},
        "cfa_loadings": json.loads(cfa_loadings.to_json(orient="records")),
        "top_profiles": json.loads(top_profiles.to_json(orient="records")),
        "manual_demo": manual_demo_spec(data_frame, loadings),
    }


def run_pipeline() -> dict[str, object]:
    paths = project_paths()
    data_frame = load_data(paths["data_path"])
    model_building, holdout = split_holdout(data_frame)
    factorability, item_metrics = factorability_metrics(data_frame)
    scree, suggested_factors = scree_table(model_building)
    loadings, communalities, factor_scores, analyzer, mapping = run_efa(model_building, n_factors=len(FACTOR_ORDER))
    cfa_fit, cfa_loadings = fit_cfa(model_building)
    holdout_fit, _ = fit_cfa(holdout)

    all_factor_scores = factor_scores_frame(analyzer, data_frame, mapping, n_factors=len(FACTOR_ORDER))
    respondent_scores = pd.concat([data_frame.reset_index(drop=True), all_factor_scores], axis=1)
    respondent_scores.insert(0, "respondent_id", np.arange(1, len(respondent_scores) + 1))

    write_artifact(paths["output_dir"] / "item_metrics.csv", lambda path: item_metrics.to_csv(path, index=False))
    write_artifact(paths["output_dir"] / "scree.csv", lambda path: scree.to_csv(path, index=False))
    write_artifact(paths["output_dir"] / "loadings.csv", lambda path: loadings.to_csv(path))
    write_artifact(paths["output_dir"] / "communalities.csv", lambda path: communalities.to_csv(path, index=False))
    write_artifact(paths["processed_dir"] / "respondent_factor_scores.csv", lambda path: respondent_scores.to_csv(path, index=False))
    write_artifact(paths["output_dir"] / "cfa_loadings.csv", lambda path: cfa_loadings.to_csv(path, index=False))
    write_artifact(paths["output_dir"] / "cfa_fit.csv", lambda path: pd.DataFrame([cfa_fit]).to_csv(path, index=False))
    write_artifact(paths["output_dir"] / "holdout_fit.csv", lambda path: pd.DataFrame([holdout_fit]).to_csv(path, index=False))

    payload = build_payload(
        data_frame,
        model_building,
        holdout,
        factorability,
        item_metrics,
        scree,
        suggested_factors,
        loadings,
        communalities,
        factor_scores,
        cfa_fit,
        holdout_fit,
        cfa_loadings,
    )
    write_artifact(paths["output_dir"] / "dashboard.json", lambda path: path.write_text(json.dumps(payload, indent=2), encoding="utf-8"))
    return payload


if __name__ == "__main__":
    result = run_pipeline()
    print(json.dumps(result["overview"], indent=2))
