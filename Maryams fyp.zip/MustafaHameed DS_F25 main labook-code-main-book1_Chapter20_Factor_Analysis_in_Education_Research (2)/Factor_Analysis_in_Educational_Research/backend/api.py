"""FastAPI server for ch20 factor analysis studio.

Mirrors runManualAnalysis(): standardize each item with its mean/std, then
weight by factor loadings to produce factor scores.

Run via:
    python -m uvicorn backend.api:app --host 127.0.0.1 --port 9520
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_DASHBOARD_PATH = _PROJECT_ROOT / "outputs" / "backend" / "dashboard.json"


def _load() -> Dict[str, Any]:
    if not _DASHBOARD_PATH.exists():
        raise RuntimeError(f"{_DASHBOARD_PATH} missing; run run/run_pipeline.ps1 first.")
    return json.loads(_DASHBOARD_PATH.read_text(encoding="utf-8"))


_DASHBOARD = _load()
_MANUAL = _DASHBOARD["manual_demo"]
_FIELD_SCHEMA: List[Dict[str, Any]] = list(_MANUAL.get("field_schema") or [])
_FACTOR_WEIGHTS: Dict[str, Dict[str, float]] = dict(_MANUAL.get("factor_weights") or {})
_FEATURE_ORDER = [f["name"] for f in _FIELD_SCHEMA]
_FIELD_BY_NAME = {f["name"]: f for f in _FIELD_SCHEMA}

_SCHEMA = {
    "input_type": "tabular",
    "feature_order": _FEATURE_ORDER,
    "field_schema": _FIELD_SCHEMA,
    "factor_weights": _FACTOR_WEIGHTS,
}


def _coerce(payload: Dict[str, Any]) -> Dict[str, float]:
    values = payload.get("values", payload)
    if not isinstance(values, dict):
        raise ValueError("payload.values must be an object")
    out: Dict[str, float] = {}
    for f in _FEATURE_ORDER:
        if f not in values:
            raise ValueError(f"missing feature: {f}")
        try:
            out[f] = float(values[f])
        except (TypeError, ValueError) as exc:
            raise ValueError(f"feature {f!r} is not numeric") from exc
    return out


def predict(payload: Dict[str, Any]) -> Dict[str, Any]:
    values = _coerce(payload)
    factor_scores: Dict[str, float] = {}
    for factor, weights in _FACTOR_WEIGHTS.items():
        score = 0.0
        for name in _FEATURE_ORDER:
            field = _FIELD_BY_NAME[name]
            mean = float(field.get("mean", 0.0))
            std = float(field.get("std", 1.0)) or 1.0
            z = (values[name] - mean) / std
            score += z * float(weights.get(name, 0.0))
        factor_scores[factor] = round(score, 4)

    ranked = sorted(factor_scores.items(), key=lambda kv: abs(kv[1]), reverse=True)
    dominant = ranked[0] if ranked else (None, None)

    return {
        "prediction": {
            "dominant_factor": dominant[0],
            "score": dominant[1],
        },
        "factor_scores": factor_scores,
        "ranked": [{"factor": k, "score": v} for k, v in ranked],
        "echo": {"values": values},
    }


app = FastAPI(title="Factor Analysis in Educational research")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root() -> Dict[str, Any]:
    return {
            "service": "Factor Analysis in Educational research",
        "status": "ready",
        "endpoints": ["/schema", "/predict"],
    }


@app.get("/schema")
def schema() -> Dict[str, Any]:
    return _SCHEMA


@app.post("/predict")
def predict_route(payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        return predict(payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
